/* @start()

Main text
-------------------
@include(sub text1)
-------------------
Main text2
-------------------
@include(sub text2)
-------------------

  /* @rstart(sub text1) 

  Include subtext1 block

  @(sub text1)
  @start(sub text2)

  Include subtext1 block

@*/
