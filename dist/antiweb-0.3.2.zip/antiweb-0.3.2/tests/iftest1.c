/* 
@start()

This is shown

@if(show)
Main Text

@include(sub text, simple_start_include.c)

@fi(show)

And This.

@*/


