The Main function ist the first one.

.. 
    
    void main() {
    
    }
    