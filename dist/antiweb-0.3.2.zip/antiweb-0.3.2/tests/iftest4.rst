The Main function ist the first one.
The source can be found in iftest4.c at line 17:

::

    
    void main() {
    
    }
    
