/* 
@start()

Main Text

@include(sub text1, block1.c)

@code*/

void main() {
  /*@rstart(complex)*/
  int i = 0;
  for(i = 0; i < 100; i++);
}

/*@edoc
<<complex>>

@include(complex)
@*/


