
Main text 


Include subtext block

This code can be found in complex_macro.c at line 24

::

    
    void main() {
      int i = 0;
    
      for(i = 0; i < 1000; i++);
    }
    

