/* 
@start()

This is shown

@if(show)
Main Text

@include(sub text1, block1.c)

@fi(show)

And This.

@*/


