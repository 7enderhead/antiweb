/*
@start(__macros__)
@define(__codeprefix__)

The code begins in file @subst(__file__) at line @subst(__line__):
@enifed(__codeprefix__)

@end(__macros__)

@start()
Test
  @code */


void main() {
}
