/* @start()

Main text
-------------------
@include(sub text1)
-------------------
Main text2
-------------------
@include(sub text2)
-------------------

  /* @start(sub text1) 

  Include subtext1 block

Stopper
  @start(sub text2)

  Include subtext2 block

@*/
