*********
Changelog
*********

    * 10.08.2015:
        Added support for C#

        Added installation instruction for use with sphinx

    * 11.08.2015:
        Added a Getting Started section for quick use

        "Installation" and "Getting Started" improvements

    * 12.08.2015:
        Added the -r flag: Process every compatible file in given directory

        Added the -i flag: All processed files will be included in Sphinx' index.rst

    * 13.08.2015:
        Added all changes to the documentation

        Copyright adaption

        Introducing a new version 0.3